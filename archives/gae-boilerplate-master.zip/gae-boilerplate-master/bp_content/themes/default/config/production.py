config = {

    # This config file will be detected in production environment and values defined here will overwrite those in config.py
    'environment': "production",

    # ----> ADD MORE CONFIGURATION OPTIONS HERE <----

}
