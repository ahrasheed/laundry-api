config = {

    # This config file will be detected in unit testing environment and values defined here will overwrite those in config.py
    'environment': "testing",

    # ----> ADD MORE CONFIGURATION OPTIONS HERE <----

}
